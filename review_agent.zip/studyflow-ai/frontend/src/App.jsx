import { useState } from 'react'
import axios from 'axios'

function App() {

  const [file, setFile] = useState(null)
  const [question, setQuestion] = useState("")
  const [answer, setAnswer] = useState("")

  const uploadFile = async () => {

    const formData = new FormData()
    formData.append("file", file)

    await axios.post(
      "http://127.0.0.1:8000/upload",
      formData
    )

    alert("上传成功")
  }

  const askQuestion = async () => {

    const res = await axios.post(
      "http://127.0.0.1:8000/ask",
      {
        question
      }
    )

    setAnswer(res.data.answer)
  }

  return (
    <div style={{padding:40}}>

      <h1>StudyFlow AI</h1>

      <input
        type="file"
        onChange={(e)=>setFile(e.target.files[0])}
      />

      <button onClick={uploadFile}>
        上传PDF
      </button>

      <hr />

      <input
        type="text"
        placeholder="输入问题"
        value={question}
        onChange={(e)=>setQuestion(e.target.value)}
        style={{width:400}}
      />

      <button onClick={askQuestion}>
        提问
      </button>

      <h3>AI回答：</h3>

      <p>{answer}</p>

    </div>
  )
}

export default App
