from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o-mini")

def summary_agent(text):
    prompt = f"""
请总结以下课程内容：

{text}
"""

    return llm.invoke(prompt)

def planning_agent(subjects):
    prompt = f"""
根据以下课程生成7天复习计划：

{subjects}
"""

    return llm.invoke(prompt)

def qa_agent(question):
    prompt = f"""
回答以下学习问题：

{question}
"""

    return llm.invoke(prompt)
