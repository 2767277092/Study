from PyPDF2 import PdfReader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain_openai import ChatOpenAI
from langchain.chains.question_answering import load_qa_chain
from dotenv import load_dotenv
import os

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

vector_db = None

def process_pdf(pdf_path):
    global vector_db

    reader = PdfReader(pdf_path)

    text = ""

    for page in reader.pages:
        text += page.extract_text()

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200
    )

    chunks = splitter.split_text(text)

    embeddings = OpenAIEmbeddings(
        openai_api_key=OPENAI_API_KEY
    )

    vector_db = FAISS.from_texts(chunks, embeddings)

def ask_question(question):
    global vector_db

    docs = vector_db.similarity_search(question)

    llm = ChatOpenAI(
        temperature=0.3,
        openai_api_key=OPENAI_API_KEY,
        model="gpt-4o-mini"
    )

    chain = load_qa_chain(llm, chain_type="stuff")

    response = chain.run(
        input_documents=docs,
        question=question
    )

    return response
