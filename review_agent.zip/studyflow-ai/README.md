# StudyFlow AI

AI 学习资料整理与智能复习 Agent

## 功能
- PDF 上传
- RAG 向量检索
- AI 问答
- 学习内容总结
- 自动生成复习计划
- 多 Agent 协作

## Backend 启动
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

## Frontend 启动
```bash
cd frontend
npm install
npm run dev
```
